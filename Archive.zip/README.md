# In_Isai_Paadal-Extractor
Download Tamil Songs with Lyrics or Get lyrics for any particular Tamil song.

**Usage:**

`python main.py --song <song_name> --save_dir <path_to_save>`
